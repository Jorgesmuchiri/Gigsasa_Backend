<?php
namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\Company;

class CompanyController extends Controller
{
    public function index(Request $request)
    {
        if ($request->query('search')) {
            $search = $request->query('search');
            $Company = Company::where('company_name', 'LIKE', "%{$search}%")->get();
        } else {
            $Company = Company::with('company_name')->orderBy('id', 'DESC')->get();
        }
        return response()->json($Company);
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $rules = [
        ];
        $validator = \Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return response()->json($validator, 422);
        } else {

            $Company = new Company;
            $Company->company_name = $request->input('company_name');
            $Company->company_logo = $request->input('company_logo');
            $Company->description = $request->input('description');
            $Company->address = $request->input('address');
            $Company->website = $request->input('website');
            $Company->email = $request->input('email');
            $Company->contact = $request->input('contact');
            

            try {
                $Company->save();
                return response()->json($Company);
            } catch (\Illuminate\Database\QueryException $e) {
                return response()->json(['status' => 'error', 'message' => $e->getMessage()]);
            }
        }
    }
    public function countCompany(Request $request)
    {
        
       $Company = Company::count();
       

       return response()->json(     $Company);
   }

   
    /**
     * Display the specified resource.
     *
     * @param  int  id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $Company = Company::whereId($id)->first();
        return response()->json($Company);
    }
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  request
     * @param  int  id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $rules = [
           
        ];
        $validator = \Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return response()->json($validator, 422);
        } else {
            $Company = Company::findOrFail($id);
            $Company->company_name = $request->input('company_name');
            $Company->company_logo = $request->input('company_logo');
            $Company->description = $request->input('description');
            $Company->address = $request->input('address');
            $Company->website = $request->input('website');
            $Company->email = $request->input('email');
            $Company->contact = $request->input('contact');
            

            try {
                $Company->save();
                return response()->json($Company);
            } catch (\Illuminate\Database\QueryException $e) {
                return response()->json(['status' => 'error', 'message' => $e->getMessage()]);
            }
        }
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
            $Company = Company::findOrFail($id);
            $Company->delete();
            return response()->json($Company, 200);
        } catch (\Illuminate\Database\QueryException $e) {
            return response()->json(['status' => 'error', 'message' => $e->getMessage()]);
        }
    }
}