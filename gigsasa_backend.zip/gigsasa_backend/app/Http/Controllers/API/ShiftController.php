<?php
namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\Shift;

class ShiftController extends Controller
{
    public function index(Request $request)
    {
        if ($request->query('search')) {
            $search = $request->query('search');
            $Shift = Shift::where('name', 'LIKE', "%{$search}%")->get();
        } else {
            $Shift = Shift::with('user.profile')->orderBy('name', 'DESC')->get();
        }
        return response()->json($Shift);
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $rules = [
        ];
        $validator = \Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return response()->json($validator, 422);
        } else {

            $Shift = new Shift;
            $Shift->user_id = $request->input('user_id');
            $Shift->shiftstarttime = $request->input('shiftstarttime');
            $Shift->shiftendtime = $request->input('shiftendtime');
            $Shift->shiftmintime = $request->input('shiftmintime');
            $Shift->shiftpattern = $request->input('shiftpattern');
            $Shift->shiftclockintime = $request->input('shiftclockintime');
            $Shift->shiftclockouttime = $request->input('shiftclockouttime');
            

            try {
                $Shift->save();
                return response()->json($Shift);
            } catch (\Illuminate\Database\QueryException $e) {
                return response()->json(['status' => 'error', 'message' => $e->getMessage()]);
            }
        }
    }
    public function countShift(Request $request)
    {
        
       $Shift = Shift::count();
       

       return response()->json(     $Shift);
   }

   
    /**
     * Display the specified resource.
     *
     * @param  int  id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $Shift = Shift::whereId($id)->first();
        return response()->json($Shift);
    }
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  request
     * @param  int  id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $rules = [
           
        ];
        $validator = \Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return response()->json($validator, 422);
        } else {
            $Shift = Shift::findOrFail($id);
            $Shift->user_id = $request->input('user_id');
            $Shift->shiftstarttime = $request->input('shiftstarttime');
            $Shift->shiftendtime = $request->input('shiftendtime');
            $Shift->shiftmintime = $request->input('shiftmintime');
            $Shift->shiftpattern = $request->input('shiftpattern');
            $Shift->shiftclockintime = $request->input('shiftclockintime');
            $Shift->shiftclockouttime = $request->input('shiftclockouttime');

            try {
                $Shift->save();
                return response()->json($Shift);
            } catch (\Illuminate\Database\QueryException $e) {
                return response()->json(['status' => 'error', 'message' => $e->getMessage()]);
            }
        }
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
            $Shift = Shift::findOrFail($id);
            $Shift->delete();
            return response()->json($Shift, 200);
        } catch (\Illuminate\Database\QueryException $e) {
            return response()->json(['status' => 'error', 'message' => $e->getMessage()]);
        }
    }
}