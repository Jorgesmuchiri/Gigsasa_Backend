<?php
namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\TimeClock;

class TimeClockController extends Controller
{
    public function index(Request $request)
    {
        if ($request->query('search')) {
            $search = $request->query('search');
            $Shift = Shift::where('name', 'LIKE', "%{$search}%")->get();
        } else {
            $Shift = Shift::with('user.profile')->orderBy('name', 'DESC')->get();
        }
        return response()->json($Shift);
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $rules = [
        ];
        $validator = \Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return response()->json($validator, 422);
        } else {
            

            $TimeClock = new TimeClock;
            $TimeClock->user_id = $request->input('user_id');
            $TimeClock->shift_id = $request->input('shift_id');
            $TimeClock->startdate = $request->input('startdate');
            $TimeClock->stopdate = $request->input('stopdate');
            $TimeClock->startlat = $request->input('startlat');
            $TimeClock->stoplat = $request->input('stoplat');
            $TimeClock->shiftclockintime = $request->input('shiftclockintime');
            $TimeClock->shiftclockouttime = $request->input('shiftclockouttime');
            

            try {
                $Shift->save();
                return response()->json($Shift);
            } catch (\Illuminate\Database\QueryException $e) {
                return response()->json(['status' => 'error', 'message' => $e->getMessage()]);
            }
        }
    }
    public function countShift(Request $request)
    {
        
       $TimeClock = TimeClock::count();
       

       return response()->json($TimeClock);
   }

   
    /**
     * Display the specified resource.
     *
     * @param  int  id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $TimeClock = TimeClock::whereId($id)->first();
        return response()->json($TimeClock);
    }
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  request
     * @param  int  id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $rules = [
           
        ];
        $validator = \Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return response()->json($validator, 422);
        } else {
            $TimeClock = TimeClock::findOrFail($id);
            $TimeClock->user_id = $request->input('user_id');
            $TimeClock->shift_id = $request->input('shift_id');
            $TimeClock->startdate = $request->input('startdate');
            $TimeClock->stopdate = $request->input('stopdate');
            $TimeClock->startlat = $request->input('startlat');
            $TimeClock->stoplat = $request->input('stoplat');
            $TimeClock->shiftclockintime = $request->input('shiftclockintime');
            $TimeClock->shiftclockouttime = $request->input('shiftclockouttime');

            try {
                $TimeClock->save();
                return response()->json($TimeClock);
            } catch (\Illuminate\Database\QueryException $e) {
                return response()->json(['status' => 'error', 'message' => $e->getMessage()]);
            }
        }
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
            $TimeClock = TimeClock::findOrFail($id);
            $TimeClock->delete();
            return response()->json($TimeClock, 200);
        } catch (\Illuminate\Database\QueryException $e) {
            return response()->json(['status' => 'error', 'message' => $e->getMessage()]);
        }
    }
}