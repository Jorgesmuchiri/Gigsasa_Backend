<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Company extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'comapany_name','company_logo','description','address','website','email','contact'
    ];

    protected $table = 'company';


}
