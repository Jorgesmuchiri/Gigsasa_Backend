<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Shift extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'user_id','shiftstarttime','shiftendtime','shiftmintime','shiftpattern','shiftclockintime','shiftclockouttime'
    ];

    protected $table = 'shift';


}
