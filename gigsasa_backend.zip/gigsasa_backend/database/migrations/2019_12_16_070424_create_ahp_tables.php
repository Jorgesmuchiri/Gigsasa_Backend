<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAHPTables extends Migration
{
  public function up()
    {
      

        Schema::create('employee_profiles', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('user_id');
            $table->string('fname');
            $table->string('lname');
            $table->string('gender');
            $table->date('dob');
            $table->string('profile_pic')->default('default_pic.png');
            $table->string('phone_no')->nullable()->unique();

            $table->timestamps();

          
        });
          
      
        Schema::create('company', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('company_name');
            $table->string('company_logo');
            $table->string('description');
            $table->string('address');
            $table->string('website');
            $table->string('email');
            $table->string('contact');
        
            $table->timestamps();
        });

        Schema::create('company_location', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('company_name');
            $table->string('address1');
            $table->string('address2');
            $table->string('headquarters');
            $table->string('longitude');
            $table->string('latitude');
            
            $table->timestamps();

        });
    
        Schema::create('shift', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('user_id');
            $table->string('shiftstarttime');
            $table->string('shiftendtime');
            $table->string('shiftmintime');
            $table->string('shiftpattern');
            $table->string('shiftclockintime');
            $table->string('shiftclockouttime');

            $table->timestamps();
          
        });

        Schema::create('timeclock', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('user_id');
            $table->string('shift_id');
            $table->string('startdate');
            $table->string('stopdate');
            $table->string('startlat');
            $table->string('stoplat');
            $table->string('shiftclockintime');
            $table->string('shiftclockouttime');

            $table->timestamps();
          
            $table->foreign('shift_id')->references('id')->on('shift');
        });

        Schema::create('assignment', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('user_id');
            $table->string('status');
            $table->string('chechin');
            $table->string('checkout');
            $table->string('manager');
            $table->string('events');
           

            $table->timestamps();

          
        });


        
    Schema::create('login_activities', function (Blueprint $table) {
        $table->increments('id');
        $table->integer('user_id')->unsigned()->index()->nullable();
        $table->foreign('user_id')->references('id')->on('users')->onDelete('set null');
        $table->string('user_agent');
        $table->string('ip_address', 45);
        $table->timestamps();
    });



        Schema::create('notifications', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('type');
            $table->morphs('notifiable');
            $table->text('data');
            $table->timestamp('read_at')->nullable();
            $table->timestamps();
        });
    
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //Schema::dropIfExists('permission_management');
    }
}

