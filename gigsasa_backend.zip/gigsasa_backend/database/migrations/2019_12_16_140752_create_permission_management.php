<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePermissionManagement extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Eloquent::unguard();
        $adminRole = \App\Models\Role::create(['name' => 'Admin']);
        $CompanyRole = \App\Models\Role::create(['name' => 'Company']);
        $EmployerRole = \App\Models\Role::create(['name' => 'Employer']);

        $individualPermissions = [
            //request services
            ['name' => 'individual_shift', 'display_name' => 'Can View Shift'],
            //individual profile
            ['name' => 'individual_profile', 'display_name' => 'Can Setup Individual Profile'],
        ];
        $companyPermissions = [
            //receive services
            ['name' => 'set_up_profile', 'display_name' => 'Can Set Up Profile'],
            
            ['name' => 'manage)_employees', 'display_name' => 'Can Manage Employees'],

           
        ];
        $adminPermissions = [
            //Driver profile
            ['name' => 'update_information', 'display_name' => 'Can Update Information'],
        ];

        foreach ($individualPermissions as $permission) {
            \App\Models\Permission::create($permission);
        }
        foreach ($companyPermissions as $permission) {
            \App\Models\Permission::create($permission);
        }
        foreach ($adminPermissions as $permission) {
            \App\Models\Permission::create($permission);
        }

        $individualPermissions = \App\Models\Permission::whereId(1)->orWhere('id',2)->get();
        //Assign all individualPermissions to role individualRole
        foreach ($individualPermissions as $permission) {
            $individualRole->attachPermission($permission);
        }
        $companyPermissions = \App\Models\Permission::whereId(3)->orWhere('id',4)->orWhere('id',5)->get();
        //Assign all companyPermissions to role hospitalRole
        foreach ($companyPermissions as $permission) {
            $companyRole->attachPermission($permission);
        }
        $adminPermissions = \App\Models\Permission::whereId(6)->get();
        //Assign all healthWorkerPermissions to role adminRole
        foreach ($adminPermissions as $permission) {
            $adminRole->attachPermission($permission);
        }


        Eloquent::reguard();
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //Schema::dropIfExists('permission_management');
    }
}
