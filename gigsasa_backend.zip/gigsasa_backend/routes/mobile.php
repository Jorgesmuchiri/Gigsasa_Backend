<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| Mobile Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "mobile" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->group( function () {
    Route::post('/userDeviceRegister', 'API\MobileController@userDeviceRegister');
    Route::post('/geocodeLocation', 'API\MobileController@geocodeLocation');
});